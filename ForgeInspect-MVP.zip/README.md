# ForgeInspect

**ForgeInspect** is a local-first, cross-platform static triage tool for APKs and other app packages. It runs with Python on Android/Termux, Windows, macOS, and Linux.

It is intended for apps you own, open-source apps, or packages you have explicit permission to examine. It does **not** clone proprietary games, bypass anti-cheat, defeat licensing/DRM, extract player accounts, or modify online games.

## Current MVP features

- SHA-256 hash and file-size report
- ZIP/APK archive integrity check and entry listing
- Lists DEX files and native library files
- Finds readable URLs, IP address-like strings, and selected interesting strings
- Writes a JSON report locally; never uploads the target file
- Uses Python standard library only

## Important limitations

This is a **static triage MVP**, not a full reverse-engineering suite or malware verdict. It does not fully decode Android's binary manifest, decompile Java/Kotlin, reconstruct native code, or run the app. Strings and IP matches can be false positives. Use a disposable test environment and only analyze packages you are authorized to inspect.

## Install and run

### Android / Termux

1. Install Termux from its official source: https://termux.dev/
2. Open Termux and run:

```sh
pkg update
pkg install python
termux-setup-storage
```

3. Put the APK in `Download`, then run (adjust the filename):

```sh
python forgeinspect.py ~/storage/shared/Download/sample.apk
```

The JSON report appears in `forgeinspect-reports/`.

### Windows

Install Python 3.10+ from https://www.python.org/downloads/ and enable **Add Python to PATH**. In PowerShell, from this folder:

```powershell
py .\forgeinspect.py "C:\path\to\sample.apk"
```

### macOS

Install Python 3 from https://www.python.org/downloads/ or use the system's approved package manager. In Terminal:

```sh
python3 forgeinspect.py "$HOME/Downloads/sample.apk"
```

### Linux

```sh
python3 forgeinspect.py ./sample.apk
```

No pip dependencies are required.

## Example report

```json
{
  "tool": "ForgeInspect",
  "scope": "local static triage only; findings are indicators, not proof of malware",
  "file": "sample.apk",
  "size_bytes": 12345,
  "sha256": "...",
  "file_type_hint": "APK/ZIP",
  "urls": [],
  "ip_addresses": [],
  "interesting_strings": []
}
```

## Safe deeper-analysis workflow

For authorized Android analysis, pair this tool with reputable, independently installed tools such as Android SDK `apkanalyzer`/`aapt` and JADX. Check their official documentation and releases. Do not run untrusted APKs on your main phone or sign into personal accounts in a test environment.

## Roadmap

- [ ] Optional manifest decoding via Android SDK tools
- [ ] Optional JADX integration (user-installed; never bundled)
- [ ] CSV/HTML report export
- [ ] Unit tests and CI
- [ ] Desktop GUI

## License

MIT. See [LICENSE](LICENSE).
