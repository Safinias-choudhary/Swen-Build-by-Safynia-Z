import json
import tempfile
import unittest
import zipfile
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from forgeinspect import analyze

class ForgeInspectTests(unittest.TestCase):
    def test_zip_report(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            sample = root / "sample.apk"
            with zipfile.ZipFile(sample, "w") as z:
                z.writestr("classes.dex", b"fake dex https://example.com/api")
                z.writestr("AndroidManifest.xml", b"manifest")
            out, report = analyze(sample, root / "out")
            self.assertTrue(out.exists())
            self.assertTrue(report["has_android_manifest"])
            self.assertIn("classes.dex", report["dex_files"])
            self.assertTrue(any("example.com" in u for u in report["urls"]))
            self.assertEqual(json.loads(out.read_text())["tool"], "ForgeInspect")

if __name__ == "__main__":
    unittest.main()
