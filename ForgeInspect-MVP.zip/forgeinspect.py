#!/usr/bin/env python3
"""ForgeInspect: safe, local-first static triage for APKs and other app packages."""
import argparse, hashlib, json, os, re, shutil, subprocess, sys, zipfile
from pathlib import Path

SUSPICIOUS_PERMISSIONS = {
    "android.permission.READ_SMS": "SMS access",
    "android.permission.RECEIVE_SMS": "Receive SMS",
    "android.permission.SEND_SMS": "Send SMS",
    "android.permission.READ_CONTACTS": "Read contacts",
    "android.permission.RECORD_AUDIO": "Microphone access",
    "android.permission.CAMERA": "Camera access",
    "android.permission.ACCESS_FINE_LOCATION": "Precise location",
    "android.permission.READ_CALL_LOG": "Read call history",
    "android.permission.REQUEST_INSTALL_PACKAGES": "Install packages",
    "android.permission.SYSTEM_ALERT_WINDOW": "Draw over other apps",
    "android.permission.BIND_ACCESSIBILITY_SERVICE": "Accessibility service capability",
}
URL_RE = re.compile(rb"https?://[A-Za-z0-9._~:/?#\[\]@!$&'()*+,;=%-]{5,}", re.I)
IP_RE = re.compile(rb"\b(?:\d{1,3}\.){3}\d{1,3}\b")

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()

def strings_from_bytes(data, min_len=5):
    # ASCII printable strings; useful for triage, not a complete decompiler.
    for m in re.finditer(rb"[\x20-\x7e]{%d,}" % min_len, data):
        yield m.group().decode("utf-8", "replace")

def analyze(path, outdir):
    p = Path(path).expanduser().resolve()
    if not p.is_file():
        raise FileNotFoundError(f"Not a file: {p}")
    size = p.stat().st_size
    result = {
        "tool": "ForgeInspect",
        "scope": "local static triage only; findings are indicators, not proof of malware",
        "file": p.name, "size_bytes": size, "sha256": sha256(p),
        "file_type_hint": "APK/ZIP" if zipfile.is_zipfile(p) else "unknown/binary",
        "archive_entries": [], "permissions": [], "urls": [], "ip_addresses": [],
        "interesting_strings": [], "notes": []
    }
    raw = p.read_bytes()
    urls = sorted({u.decode("utf-8", "replace").rstrip(".,);]") for u in URL_RE.findall(raw)})
    ips = sorted({x.decode() for x in IP_RE.findall(raw)})
    result["urls"] = urls[:500]
    result["ip_addresses"] = ips[:200]
    strings = list(strings_from_bytes(raw))
    keywords = re.compile(r"(http|https|token|password|secret|api[_-]?key|socket|websocket|root|frida|xposed|debug|emulator|cheat|aimbot|anti.?cheat|certificate|encrypt|decrypt)", re.I)
    result["interesting_strings"] = [s[:500] for s in strings if keywords.search(s)][:500]
    if zipfile.is_zipfile(p):
        try:
            with zipfile.ZipFile(p) as z:
                bad = z.testzip()
                result["archive_integrity"] = "ok" if bad is None else f"CRC error: {bad}"
                result["archive_entries"] = [
                    {"name": i.filename, "size": i.file_size}
                    for i in z.infolist()[:2000]
                ]
                result["has_android_manifest"] = any(i.filename == "AndroidManifest.xml" for i in z.infolist())
                result["native_libraries"] = [i.filename for i in z.infolist() if i.filename.endswith((".so", ".dylib", ".dll"))][:200]
                result["dex_files"] = [i.filename for i in z.infolist() if re.fullmatch(r"classes\d*\.dex", Path(i.filename).name)][:100]
                # Extract readable strings from DEX and XML entries only; never execute package code.
                for info in z.infolist():
                    if info.file_size > 25_000_000:
                        continue
                    if info.filename.endswith((".dex", ".xml", ".json", ".txt", ".properties")):
                        try:
                            chunk = z.read(info)
                            for s in strings_from_bytes(chunk):
                                if keywords.search(s):
                                    result["interesting_strings"].append(f"[{info.filename}] {s[:400]}")
                            result["urls"].extend(u.decode("utf-8", "replace").rstrip(".,);]") for u in URL_RE.findall(chunk))
                        except (RuntimeError, OSError, zipfile.BadZipFile):
                            pass
        except (OSError, zipfile.BadZipFile) as e:
            result["notes"].append(f"Archive read issue: {e}")
    result["urls"] = sorted(set(result["urls"]))[:500]
    result["interesting_strings"] = list(dict.fromkeys(result["interesting_strings"]))[:500]
    result["notes"].append("AndroidManifest.xml may be binary AXML; permissions are not decoded by this standard-library-only version.")
    result["notes"].append("Use a trusted, up-to-date Android SDK/aapt or JADX separately for deeper analysis. Never install unknown APKs on your primary device.")
    out = Path(outdir).expanduser().resolve()
    out.mkdir(parents=True, exist_ok=True)
    dest = out / (p.name + ".forgeinspect.json")
    dest.write_text(json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8")
    return dest, result

def main():
    ap = argparse.ArgumentParser(description="Local static triage for app packages. Does not execute or modify target apps.")
    ap.add_argument("file", help="Path to APK, ZIP, or other binary file")
    ap.add_argument("-o", "--out", default="forgeinspect-reports", help="Output directory")
    args = ap.parse_args()
    try:
        dest, report = analyze(args.file, args.out)
    except (OSError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        return 2
    print(f"ForgeInspect report: {dest}")
    print(f"SHA-256: {report['sha256']}")
    print(f"Size: {report['size_bytes']} bytes")
    print(f"Archive: {report['file_type_hint']}")
    print(f"URLs found: {len(report['urls'])}")
    print(f"Interesting strings: {len(report['interesting_strings'])}")
    print("Reminder: static indicators are not a malware verdict.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
